import { LightningElement,api,track,wire } from 'lwc';
import showData from '@salesforce/apex/HandlerFlightFilterAirlines.displayData';

const mycolumns=[
    {label:'BookingNumber', fieldName:'BookingNumber__c'},
    {label:'Bookings Name',fieldName:'Name'},
    {label:'Source',fieldName:'Source__c'},
    {label:'Destination',fieldName:'Destination__c'},
    {label:'Date',fieldName:'Date__c'},
    {label:'Status',fieldName:'Status__c'},
    
];

export default class relatedBooking extends LightningElement {
    @track bookingList = [];
    columns = mycolumns;
    @api flight;

    @wire(showData,{flight: '$flight'})
    myShowProduct({error,data}){
        if(data){
            console.log(data);
            this.bookingList = data;
        }
        if(error){
            console.log(error);
        }
    }
}