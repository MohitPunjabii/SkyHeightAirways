import { LightningElement, api, wire } from 'lwc';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';
 
 
const NAME_FIELD = 'Passenger__c.Name';
const LOCATION = 'Passenger__c.Address__c';
const locFields = [
    NAME_FIELD,
    LOCATION
];
 
export default class LocationAddress extends LightningElement {
 
    @api recordId;
    name;
    mapMarkers = [];
    @wire(getRecord, { recordId: '$recordId', fields: locFields })
    loadBear({ error, data }) {
        if (error) {
        // TODO: handle error
        } else if (data) {
        // Get Bear data
        this.name =  getFieldValue(data, NAME_FIELD);
        this.LOCATION = getFieldValue(data, LOCATION);
        // Transform bear data into map markers
        this.mapMarkers = [{
            location: {
                City: this.LOCATION,
            },
            title: this.name,
        }];
        }
    }
    get cardTitle() {
        return (this.name) ? `${this.name}'s location` : 'Passenger location';
    }
}